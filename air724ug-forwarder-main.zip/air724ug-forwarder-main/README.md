# Air724UG 短信转发 & 来电通知 & 语音信箱

## 项目介绍及使用教程

https://mizore.notion.site/air724ug-forwarder-227b5a41fa5f4be1bdd356275a31d277